const SongList = () => {
  return <div>SongList</div>;
};

export default SongList;
