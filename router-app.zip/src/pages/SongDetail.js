const SongDetail = () => {
  return <div>SongDetail</div>;
};

export default SongDetail;
