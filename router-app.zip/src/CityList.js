import CityItem from "./CityItem";

const CityList = (props) => {
  const listArr = props.cities;
  const cities = listArr.map((item, index) => {
    return (
      // 반복문은 key 가 필요하며, unique 값이어야 한다.
      <CityItem item={item} key={item.id} />
    );
  });
  return <ul className="list-group">{cities}</ul>;
};

export default CityList;
