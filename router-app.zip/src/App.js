import CityList from "./CityList";

const App = () => {
  // 보간법 : interpolation   { 결과값 }
  const msg = "Hello";
  // 예제 데이터
  const listArr = [
    { id: 1, city: "대구", visited: true },
    { id: 2, city: "부산", visited: false },
    { id: 3, city: "광주", visited: false },
    { id: 4, city: "서울", visited: true },
    { id: 5, city: "제주", visited: false },
  ];

  // JSX 에서 활용를 하려는 메서드는 리터값이 있어야 합니다.
  const addResult = (x, y) => {
    return (
      <div className="card card-body bg-light mb-3">
        {x} + {y} = {x + y}{" "}
      </div>
    );
  };

  return (
    <div className="container">
      <h2>{msg} World!</h2>
      <hr className="line" />
      <div>{addResult(3, 4)}</div>
      <CityList cities={listArr} />
    </div>
  );
};

export default App;
